import React, {useState} from "react";
import {useNavigate} from "react-router-dom";

const Register =()=>{
    const [name, setName]=useState("");
    const [email, setEmail]=useState("");
    const [password, setPassword]=useState("");
    const [message, setMessage]=useState("");
    const navigate = useNavigate();

    const handleRegister = async (e)=>{
        e.preventDefault();
        setMessage("");

        try{
            const response = await fetch("https://localhost:3001/api/users/reservationh",{
                method:"POST",
                headers:{
                    "Content-type":"application/json",
                },
                body:JSON.stringify({name, email, password})
            });
            if(response.ok){
                setMessage("Registration successfull");
                setTimeout(()=>navigate("login"),2000);
            }else{
                const error = await response.json();
                setMessage(error.message || "Registration failed, please try again");
            }
        }catch(error){

        }
    }



    return (
        <div className="container mt-5">
          <div className="row justify-content-center">
            <div className="col-md-6">
              <div className="card">
                <div className="card-header text-center">
                  <h3>Register</h3>
                </div>
                <div className="card-body">
                  <form onSubmit={handleRegister}>
                    <div className="mb-3">
                      <label htmlFor="name" className="form-label">
                        Name
    </label>
                      <input
                        type="text"
                        className="form-control"
                        id="name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        required
                      />
                    </div>
                    <div className="mb-3">
                      <label htmlFor="email" className="form-label">
                        Email Address
                      </label>
    <input
                        type="email"
                        className="form-control"
                        id="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                      />
                    </div>
                    <div className="mb-3">
                      <label htmlFor="password" className="form-label">
                        Password
                      </label>
                      <input
                        type=
    "password"
                        className="form-control"
                        id="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                      />
                    </div>
                    <button type="submit" className="btn btn-primary w-100">
                      Register
                    </button>
    </form>
                  {message && (
                    <div className="alert alert-info mt-3" role="alert">
                      {message}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      );
}
export default Register;
import React from "react";

const Home = () => {
  return (
    <div className="container">
      <h1>Welcome to Hotel Reservation System</h1>
      <p>Book your dream room now!</p>
    </div>
  );
};

export default Home;